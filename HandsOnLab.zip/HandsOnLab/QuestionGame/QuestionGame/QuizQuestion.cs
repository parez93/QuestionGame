﻿namespace QuestionGame
{
    public class QuizQuestion
    {
        // TODO!

    }
}
