﻿using System;


using Xamarin.Forms;

namespace QuestionGame
{
    public partial class QuestionPage : ContentPage
    {
        Game game;
        public QuestionPage()
        {
            game = App.CurrentGame;

            InitializeComponent();

            InitializeControls();
        }

        void InitializeControls()
        {
            btnTrue.Clicked += (s, e) => OnAnswer(true);
            btnFalse.Clicked += (s, e) => OnAnswer(false);

            btnNext.Clicked += OnNextClicked;

            ResetUI();
        }

        void ResetUI()
        {
            // TODO!
        }

        void OnAnswer(bool answer)
        {
           // TODO!
        }

        void OnNextClicked(object sender, EventArgs e)
        {
          // TODO!
        }
    }
}
